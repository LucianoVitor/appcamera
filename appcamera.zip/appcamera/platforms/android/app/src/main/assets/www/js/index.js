/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

// Wait for the deviceready event before using any of Cordova's device APIs.
// See https://cordova.apache.org/docs/en/latest/cordova/events/events.html#deviceready
document.addEventListener('deviceready', onDeviceReady, false);

function onSucesso(imageURI) {
    //se essa funcao ta rodando
    //significa que a foto foi tirada com sucesso
    //imageURI indica onde a foto esta no nosso celular
    let tagImg = document.getElementById("imgFoto");
    tagImg.src = "data:image/jpeg;base64,"+imageURI;
}

function onFalha() {
    alert("Falha ao tirar a foto");
    console.dir(err);
}

var opcoes = {
    quality: 50,
        destinationType: Camera.DestinationType.DATA_URL,
        allowEdit: true,
        saveToPhotoAlbum: false,
        cameraDirection: 1,
        sourceType: Camera.PictureSourceType.CAMERA
}
btnAbreCamera.addEventListener('click', function(){
    alert("Vamos tirar uma foto!");
    navigator.camera.getPicture(onSucesso,onFalha,opcoes);
    })

function abrirCamera(){

    navigator.camera.getPicture(onSucesso, onFalha,opcoes);


}

function onDeviceReady() {
    // Cordova is now initialized. Have fun!
    //aqui dentro desse metodo temos certeza que os plugins estao devidamente ativados

    console.log('Running cordova-' + cordova.platformId + '@' + cordova.version);
    let btnAbreCamera = document.getElementById("btnTirarFoto");
    btnAbreCamera.addEventListener("click", function(){
    alert("botao clicado");
    })
}
